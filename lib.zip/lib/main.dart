import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:weather_assistant/app.dart';
import 'package:weather_assistant/bloc/screens/favorite/favorite_info_bloc.dart';
import 'package:weather_assistant/config/config.dart';
import 'package:intl/intl.dart';
final getIt = GetIt.instance;
void main()async {
  WidgetsFlutterBinding.ensureInitialized();
  await initDepends();
  runApp(const WeatherAssistantApp());
}
Future<void> initDepends() async {
  configureDependencies();
  getIt.get<FavoriteInfoBloc>();
}
