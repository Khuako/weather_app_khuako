import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:weather_assistant/config/api_keys.dart';
import 'package:xml/xml.dart';

Future<Map<String, dynamic>> fetchWeatherData(LatLng mapPoint) async {
  try {
    final response = await http.get(
        Uri.parse(
            'https://weatherapi-com.p.rapidapi.com/current.json?q=${mapPoint.latitude}%2C${mapPoint.longitude}&lang=ru'),
        headers: {
          'X-RapidAPI-Key': weatherApiKey,
          'X-RapidAPI-Host': 'weatherapi-com.p.rapidapi.com',
        });
    if (response.statusCode == 200) {
      final decodedBody = utf8.decode(response.bodyBytes);
      print(decodedBody);
      return jsonDecode(decodedBody);
    } else {
      throw Exception("Плохой статус");
    }
  } catch (ex) {
    debugPrint(ex.toString());
    throw Exception("Не удалось получить информацию");
  }
}

Future<Map<String, dynamic>> fetchWeatherForecast(LatLng mapPoint) async {
  try {
    final response = await http.get(
      Uri.parse(
          'https://api.open-meteo.com/v1/forecast?latitude=${mapPoint.latitude}&longitude=${mapPoint.longitude}&hourly=temperature_2m&&forecast_days=7'),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Плохой статус");
    }
  } catch (ex) {
    debugPrint(ex.toString());
    throw Exception("Не удалось получить информацию");
  }
}

Future<Map<String, dynamic>> fetchWeatherForecastByDays(String? city, LatLng? mapPoint, int days)
async {
  try {
    final response = await http.get(
      Uri.parse('https://api.weatherapi.com/v1/forecast'
          '.json?key=$forecastKey${city != null ? '&q=$city' : ''}${mapPoint != null ? 'q=${mapPoint.latitude}%2C${mapPoint.longitude}' : ''}&days=$days&aqi=no&alerts=no'),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Плохой статус");
    }
  } catch (ex) {
    debugPrint(ex.toString());
    throw Exception("Не удалось получить информацию");
  }
}

Future<Map<String, dynamic>> fetchWeatherDataByName(String city) async {
  try {
    final response = await http
        .get(Uri.parse('https://weatherapi-com.p.rapidapi.com/current.json?q=${city}'), headers: {
      'X-RapidAPI-Key': weatherApiKey,
      'X-RapidAPI-Host': 'weatherapi-com.p.rapidapi.com',
    });
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception("Плохой статус");
    }
  } catch (ex) {
    debugPrint(ex.toString());
    throw Exception("Не удалось получить информацию");
  }
}
