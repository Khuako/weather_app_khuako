import 'package:weather_assistant/data/models/autocomplete_model.dart';

