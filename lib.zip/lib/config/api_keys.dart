const mapApiKey = '7a5108a2a24546d59fce31751ba3af27';
const weatherApiKey = '0db7671a29msh02b018905d947a1p14e464jsn12928448f8ab';
const forecastKey = '4e0001d47947433d836163007231309';